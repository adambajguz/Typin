﻿namespace TypinExamples.CalculatOR.Domain
{
    public enum NumberBase
    {
        BIN = 2,
        DEC = 10,
        HEX = 16
    }
}
