# Libraries folder

This folder contains all CSS and JS libraries used in the app.

**DO NOT MODIFY files inside this folder/subfolders!**